let myDate = new Date()
console.log(myDate.toLocaleTimeString());